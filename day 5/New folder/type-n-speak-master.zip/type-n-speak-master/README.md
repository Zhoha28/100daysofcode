# Type-N-Speak

> Type and speak app with speech synthesis using the [Web Speech API](https://developer.mozilla.org/en-US/docs/Web/API/Web_Speech_API)

[App Demo](https://bradtraversy.github.io/type-n-speak)
